export interface RecursiveArray<T> extends Array<RecursiveArray<T> | T> {
}
