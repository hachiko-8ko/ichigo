/**
 * I don't know how accurate this is but it seems pretty good
 */
export declare function isPrimitive(obj: any): boolean;
