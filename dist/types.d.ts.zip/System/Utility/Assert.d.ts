/**
 * Dead simple assertion that'll work anywhere. This is NOT the difficult part of unit testing.
 */
export declare function assert(test: boolean, message?: string): void;
