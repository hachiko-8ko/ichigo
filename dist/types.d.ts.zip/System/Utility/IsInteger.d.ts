/**
 * Tell if a given string is a positive integer.
 * Use for detecting array keys.
 */
export declare function isPositiveIntegerString(str: any): boolean;
