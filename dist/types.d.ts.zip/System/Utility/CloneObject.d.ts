export declare function cloneObject<T extends Record<string, any>>(obj: T): T | undefined;
