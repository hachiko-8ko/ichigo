export declare function delay(time: number): (result: any) => Promise<{}>;
