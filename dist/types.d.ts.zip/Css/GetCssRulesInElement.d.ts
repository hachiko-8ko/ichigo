export declare function getCssRulesInElement(element: HTMLElement): string;
