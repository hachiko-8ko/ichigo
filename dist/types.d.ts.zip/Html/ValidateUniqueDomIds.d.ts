/**
 * If the document contains any duplicate IDs, throw an exception.
 */
export declare function validateUniqueDomIds(): void;
