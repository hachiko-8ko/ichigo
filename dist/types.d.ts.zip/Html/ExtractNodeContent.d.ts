/**
 * Get the contents of any html node as a DocumentFragment.
 */
export declare function extractNodeContent(node: Node): DocumentFragment;
