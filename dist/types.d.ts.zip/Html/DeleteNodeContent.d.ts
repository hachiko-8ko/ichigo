/**
 * Delete the contents of any html node.
 */
export declare function deleteNodeContent(node: Node): void;
