import { Nullable } from "../System/Types/NoneType";
export declare function findIndexInParent(element: Element): Nullable<number>;
